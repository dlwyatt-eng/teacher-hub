# Nature Today — October–November observation bank

Start with one photograph and a 2–5-minute routine: Notice, Explain, Revisit.
The 15 photographs are archival references, not current local sightings.

1. Open Nature_Today_Teacher_Pack.pdf for the routine, Grade 6 curriculum connections and optional inclusive buddy observation.
2. Project a page of Nature_Today_Image_Bank.pdf. Read the place, date and description as needed. Invite visible evidence before explanations.
3. Print only the needed pages from Nature_Today_Student_Journal.pdf. Students can also speak, point, draw or use their usual communication method.
4. Return to a familiar, accessible place later to build a dated record of change. This bank does not contain matched before/after photographs.

Contents
- Teacher pack: 8 pages
- Student journal: 6 low-ink pages
- Image bank: 15 landscape pages, one photo with prompts and credits per page
- images/: 15 full-frame WebP copies
- nature-today.json: editable prompts, image descriptions, attribution and supporting links
- PHOTO_CREDITS.md: creators, original source titles, licences, places, dates and uncertainty

Web versions
https://dlwyatt-eng.github.io/teacher-hub/?view=Nature+Today
https://dlwyatt-eng.github.io/equity-hub/#nature-today

The websites select an image each Vancouver weekday during October and November and repeat the 15-image bank. Manual selections can be bookmarked. The PDFs and images work offline once downloaded; current viewing conditions and external sources still require checking.

Respect the individual image licences when redistributing or adapting this package. Resizing and format conversion are disclosed in the credits. Full frames are preserved. The PDF uses resized JPEG copies for manageable file size. Student response spaces are blank; this package contains no student records.
